MoCKA Governance Model v4 (Trust and Identity Layer)



This sample demonstrates a 2-of-3 multi-signature responsibility model.

MoCKA does not rely on hidden state, internal memory claims, or unverifiable declarations.

Only cryptographic evidence and publicly verifiable artifacts are accepted.



Directory



\- KEY\_REGISTRY\_v4.jsonl

&nbsp; Append-only key registry ledger (register, revoke).

\- samples/

&nbsp; Five verification samples (1 PASS, 4 FAIL by design).

\- verify\_all\_v4.py

&nbsp; Single command entry to verify everything.



Requirements



\- Python 3.10+

\- cryptography



Setup



python -m venv .venv

.\\.venv\\Scripts\\python -m pip install cryptography



Run



.\\.venv\\Scripts\\python .\\verify\_all\_v4.py



Expected Results



\- samples/valid\_2\_of\_3.json

&nbsp; PASS (2-of-3 signatures, using active keys only)

\- samples/insufficient\_signature.json

&nbsp; FAIL (insufficient signatures)

\- samples/duplicate\_signer.json

&nbsp; FAIL (duplicate signer)

\- samples/revoked\_key\_used.json

&nbsp; FAIL (revoked key used)

\- samples/canonical\_tamper.json

&nbsp; FAIL (payload changed after signing)



Notes



\- Canonical JSON is enforced via sorted keys and no spaces.

\- UTC timezone-aware timestamps are used.

\- Any single byte change breaks verification.

